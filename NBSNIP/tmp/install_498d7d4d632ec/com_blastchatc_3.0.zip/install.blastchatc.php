<?php
/**
 * @version		$Id: install.blastchatc.php 2009-01-01 15:24:18Z $
 * @package		BlastChat Client
 * @author 		BlastChat
 * @copyright	Copyright (C) 2004-2009 BlastChat. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * @HomePage 	<http://www.blastchat.com>

 * This file is part of BlastChat Client.

 * BlastChat Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * BlastChat Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with BlastChat Client.  If not, see <http://www.gnu.org/licenses/>.
 */

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

if (!defined('_BC_BLASTCHAT')) DEFINE("_BC_BLASTCHAT","BlastChat Client");

function com_install()
{
	global $mosConfig_absolute_path, $mosConfig_live_site, $mosConfig_lang, $database;

	// Get the languages file if it exists
	if (file_exists($mosConfig_absolute_path.'/components/com_blastchatc/languages/'.$mosConfig_lang.'.php')) {
		include_once($mosConfig_absolute_path.'/components/com_blastchatc/languages/'.$mosConfig_lang.'.php');
	}
	if ($mosConfig_lang != "english" && file_exists($mosConfig_absolute_path.'/components/com_blastchatc/languages/english.php')) {
		include_once($mosConfig_absolute_path.'/components/com_blastchatc/languages/english.php');
	}

	@ini_set( "max_execution_time", "60" );
	$database->setQuery( "CREATE TABLE IF NOT EXISTS `#__blastchatc` (
		`id` int(11) NOT NULL auto_increment,
		`url` varchar(100) default NULL,
		`intra_id` varchar(100) default NULL,
		`priv_key` varchar(100) default NULL,
		`detached` binary(1) NOT NULL default 0,
		`adm_expand` binary(1) NOT NULL default 1,
		`width` varchar(6) NOT NULL default '100%',
		`height` varchar(6) NOT NULL default '480',
		`d_width` varchar(6) NOT NULL default '640',
		`d_height` varchar(6) NOT NULL default '480',
		`frame_border` binary(1) NOT NULL default 0,
		`m_width` varchar(6) NOT NULL default '0',
		`m_height` varchar(6) NOT NULL default '0',
		PRIMARY KEY ( `id` ),
		UNIQUE KEY (`url`)
		);
		");
	if (!$database->query()) {
		$result = "Error 0013 : "._BC_CONTACTWEBMASTER."\n<br><br>".$database->stderr(true);
		return $result;
	}

	$query = "SHOW COLUMNS FROM #__blastchatc_users ";
	$database->setQuery ( $query );
	$cols = false;
	$cols = $database->loadRowList();
	if ($cols[0][0] == "userid") {
		$query = "DROP TABLE IF EXISTS `#__blastchatc_users`";
		$database->setQuery ( $query );
		$database->query();
	}

	$database->setQuery( "CREATE TABLE IF NOT EXISTS `#__blastchatc_users` (
		`bc_userid` int(11) default 0,
		`bc_lastEntry` datetime NOT NULL default '0000-00-00 00:00:00',
		`bc_idle` varchar(5) default NULL,
		`bc_rid` INT(11) NOT NULL default 0,
		`bc_rsid` INT(11) NOT NULL default 0,
		`bc_rname` VARCHAR(100) default NULL,
		PRIMARY KEY (`bc_userid`)
		);
		");
	if (!$database->query()) {
		$result = "Error 0014 : "._BC_CONTACTWEBMASTER."\n<br><br>".$database->stderr(true);
		return $result;
	}

	require_once($mosConfig_absolute_path.'/components/com_blastchatc/api.blastchatc.php');

	$mosConfig_live_site = bc_getLiveSite($mosConfig_live_site);

	//strip http or https from this website URL, global variable
	//if you need this to be something else,assign another value to $mosConfig_live_site (do same for admin.blastchac.php file):
	$bc_site = $mosConfig_live_site;
	$bc_site = strtolower($bc_site);
	$bc_site = str_replace("http://", "", $bc_site);
	$bc_site = str_replace("https://", "", $bc_site);
	
	$bc_site_other = "";
	if (strpos($bc_site, "www.") === false) {
		$bc_site_other = "www." . $bc_site;
	} else {
		$bc_site_other = str_replace("www.", "", $bc_site);
	}
	
	require_once($mosConfig_absolute_path.'/administrator/components/com_blastchatc/class.blastchatc.php');
	$website = null;
	$website = new josBC_website($database);
	$website->loadByURL( $bc_site );
	$bc_site_other = "";
	if (!$website->url) {
		$website->loadByURL( $bc_site_other );
		if (!$website->url) {
			$website->intra_id = md5( $bc_site.uniqid(microtime(), 1 ) );
			$website->url = $bc_site;
			$website->store();
		}
	}

	//Set up icons for admin area
	$result = null;
	$menu_config = _BC_MENU_CONFIG;
	$menu_config_alt = _BC_BLASTCHAT." - "._BC_MENU_CONFIG;
	$menu_reg = _BC_MENU_REG;
	$menu_reg_alt = _BC_BLASTCHAT." - "._BC_MENU_REG;
	$menu_credits = _BC_MENU_CREDITS;
	$menu_credits_alt = _BC_BLASTCHAT." - "._BC_MENU_CREDITS;
	$database->setQuery("UPDATE #__components SET admin_menu_img='../components/com_blastchatc/images/config.png', name='$menu_config', admin_menu_alt='$menu_config_alt' WHERE admin_menu_link='option=com_blastchatc&task=config'");
	if (!$database->query()) {
		$result = "Error 0010 : "._BC_CONTACTWEBMASTER."\n<br><br>".$database->stderr(true);
	} else {
		$database->setQuery("UPDATE #__components SET admin_menu_img='../components/com_blastchatc/images/credits.png', name='$menu_reg', admin_menu_alt='$menu_reg_alt' WHERE admin_menu_link='option=com_blastchatc&task=register'");
		if (!$database->query()) {
			$result = "Error 0011 : "._BC_CONTACTWEBMASTER."\n<br><br>".$database->stderr(true);
		} else {
			$database->setQuery("UPDATE #__components SET admin_menu_img='../components/com_blastchatc/images/credits.png', name='$menu_credits', admin_menu_alt='$menu_credits_alt' WHERE admin_menu_link='option=com_blastchatc&task=credits'");
			if (!$database->query()) {
				$result = "Error 0012 : "._BC_CONTACTWEBMASTER."\n<br><br>".$database->stderr(true);
			} else {
				//needed for module support, field marks which user is inside chat
				$database->setQuery( "ALTER TABLE `#__session` , ADD `bc_lastUpdate` VARCHAR( 14 ) NULL ");
				if (!$database->query()) {
					$result = "Error 0015 : "._BC_CONTACTWEBMASTER."\n<br><br>".$database->stderr(true);
				} else {
	?>
	<script type="text/javascript" src="<?php echo $mosConfig_live_site;?>/includes/js/overlib_mini.js"></script>
	<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminform"">
		<tr>
			<th width="100%"><span class="sectionname">&nbsp;<?php echo "BlastChat - free chat for your website";?></span></th>
			<th align="right" nowrap>
				<a rel="license" target="_blank" href="http://creativecommons.org/licenses/by-nc-sa/3.0/us/"><img alt="Creative Commons License" style="border-width:0" src="<?php echo $mosConfig_live_site; ?>/components/com_blastchatc/images/somerights20.png"/></a>
				&nbsp;
				<?php echo mosToolTip( _BC_LICENSE_INFO_30, _BC_LICENSE_INFO_HEADER ); ?>
			</th>
		</tr>
	</table>
	<table class="adminlist">
		<tr>
			<td>
			<b>com_blastchatc
			<br><br>
			<?php if ($result) { ?>
				BlastChat Client 3.0 - <?php echo _BC_INSTAL_FAIL;?>
				<br>
				<?php echo $result;?>
			<?php } else { ?>
				BlastChat Client 3.0 - <?php echo _BC_INSTAL;?>
			<?php } ?>
			</b>
			</td>
		</tr>
	<?php if (!$result) { ?>
		<tr>
			<td colspan="2">[&nbsp;<a href="index2.php?option=com_blastchatc&task=register" style="font-size: 16px; font-weight: bold"><?php echo _BC_REGNOW;?>&nbsp;...</a>&nbsp;]</td>
		</tr>
	<?php } ?>
	</table>
	<br><br>
	<?php
				}
			}
		}
	}
	return $result;
}

?>