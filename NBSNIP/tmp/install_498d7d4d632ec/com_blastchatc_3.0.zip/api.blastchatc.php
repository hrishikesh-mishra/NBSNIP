<?php
/**
 * @version		$Id: api.blastchatc.php 2009-01-01 15:24:18Z $
 * @package		BlastChat Client
 * @author 		BlastChat
 * @copyright	Copyright (C) 2004-2009 BlastChat. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * @HomePage 	<http://www.blastchat.com>

 * This file is part of BlastChat Client.

 * BlastChat Client is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * BlastChat Client is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with BlastChat Client.  If not, see <http://www.gnu.org/licenses/>.
 */

/** ensure this file is being included by a parent file */
defined( '_VALID_MOS' ) or defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

/*headers to force browser not to use cache
*/
function bc_sendHeaders() {
	//Headers are sent to prevent browsers from caching.. IE is still resistent sometimes
	header( "Expires: Mon, 26 Jul 1997 05:00:00 GMT" );
	header( "Last-Modified: " . gmdate( "D, d M Y H:i:s" ) . " GMT" );
	header( "Cache-Control: no-store, no-cache, must-revalidate" );
	header( "Pragma: no-cache" );
	header( "Content-Type: text/html; charset=UTF-8" );
}

/*
adjust this function to return proper group id for current user
$uid - current user id
return - current user group id, integer OR ra string in format "1,2,3" in case your system can assign multiple groups to single member
*/
function bc_getUserGroup($uid = 0) {
	global $myss;

	$gid = 0;
	if ($uid) {
		/*replace following code with database call to retreive current user group id
		//example
		$query = "SELECT groupid FROM #__xxx "
		." WHERE userid=$myss->userid";
		$database->setQuery($query);
		$gid = $database->loadResult();
		if (!$gid)
		$gid = 0;

		//or example
		global $my;
		$query = "SELECT gid FROM #__xxx "
		." WHERE userid=$my->id";
		$database->setQuery($query);
		$gid = $database->loadResult();
		if (!$gid)
		$gid = 0;

		//or combine examples as you need
		*/
		$gid = $myss->gid;
	}
	return $gid;
}

/*
adjust this function to return proper current session information for current user
$version - variable hodling information about current CMS
return $myss - variable holding session data
	$myss->guest - 1 if user is guest (not member), 1 if user is logged in member of your website
	$myss->session_id - unique session identifier for current user
	$myss->userid - unique user id if logged in member, if user is guest then this should be set to 0 (zero)
	$myss->username - unique username of currently logged in member, set to empty string "" if guest
*/
function bc_getSessionData() {
	global $mainframe, $bc_legacy, $database;

	$bc_version = bc_getVersion();

	$myss = null;
	if ($bc_version->PRODUCT == "Joomla!") {
		if ($bc_version->RELEASE < "1.5") {
			//rel=1.0, dev=x
			$myss = $mainframe->_session;
		} else {
			//rel=1.5, dev=x
			if (!$mainframe->getCfg('legacy')) {
				//for full 1.5 installation, else is 1.5 legacy mode
				$database =& JFactory::getDBO();
			} else {
				$bc_legacy = true;
			}
			$session =& JFactory::getSession();
			$myss =& JTable::getInstance( 'session', 'JTable' );
			$myss->load($session->getId());
		}
	} elseif ($bc_version->PRODUCT == "Mambo") {
		if ($bc_version->RELEASE < "4.6") {
			//rel=4.5, dev=x
			$myss = $mainframe->_session;
		} else {
			//rel=4.6, dev=x
			$myss =& mosSession::getCurrent();
		}
	}
	if (!$myss) {
		$myss = $mainframe->_session;
	}
	if (!isset($myss)) {
		echo "Session variable not defined by system, adjust file api.blastchatc.php, function bc_getSessionData().";
		exit;
	}
	/*
		//example
		$query = "SELECT guest, sessionid AS session_id, id AS userid, username FROM #__xxx "
		." WHERE userid=$my->id";
		$database->setQuery($query);
		$myss = $database->loadObject();
	*/
	return $myss;
}

/* Function updates current user timestamp for display purposes of the module
* return null
*/
function bc_userUpdate() {
	global $database, $my;

	$myss = bc_getSessionData();
	$bc_time = time();

	//update upon chat entry
	$query = "UPDATE #__session "
	." SET bc_lastUpdate='$bc_time' "
	." WHERE session_id='$myss->session_id' ";
	;
	$database->setQuery($query);
	$database->query();

	if ($myss->userid || $my->id) {
		//if member, update users table
		$id = 0;
		if ($myss->userid > 0) {
			$id = $myss->userid;
		} else if ($my->id > 0) {
			//in case Joomla session variable is not set properly, we take a look at $my variable
			$id = $my->id;
		} else {
			return false;
		}
		$idle_time = strval(mosGetParam($_REQUEST, 'idle_time', ''));
		$rid = intval(mosGetParam($_REQUEST, 'rid', 0));
		$rsid = intval(mosGetParam($_REQUEST, 'rsid', 0));
		$rname = strval(mosGetParam($_REQUEST, 'rname', ''));

		//update upon chat entry
		$query = "UPDATE #__blastchatc_users "
		." SET bc_rid=$rid "
		." , bc_rsid=$rsid "
		." , bc_rname='".mysql_real_escape_string($rname)."' "
		." , bc_idle='".mysql_real_escape_string($idle_time)."' "
		." WHERE bc_userid=$id ";
		;
		$database->setQuery($query);
		$database->query();
	}
	return true;
}

/*
update current user session data (used on user signin to chat)
*/
function bc_userSignIn() {
	global $database, $my;

	$myss = bc_getSessionData();
	$bc_time = time();

	$query = "UPDATE #__session "
	." SET bc_lastUpdate='$bc_time' "
	." WHERE session_id='$myss->session_id' "
	;
	$database->setQuery($query);
	$database->query();

	if ($myss->userid || $my->id) {
		$id = 0;
		if ($myss->userid > 0) {
			$id = $myss->userid;
		} else if ($my->id > 0) {
			//in case Joomla session variable is not set properly, we take a look at $my variable
			$id = $my->id;
		} else {
			return;
		}
		$bc_date = date("Y-m-d H:i:s");
		$query = "UPDATE #__blastchatc_users "
		." SET bc_lastEntry='$bc_date', bc_rid=0, bc_rsid=0, bc_rname=null, bc_idle=null "
		." WHERE bc_userid=$id "
		;
		$database->setQuery($query);
		$database->query();
		if ($database->getAffectedRows() < 1) {
			$query = "INSERT INTO #__blastchatc_users "
			." ( bc_userid, bc_lastEntry ) VALUES ( $id, '$bc_date' ) "
			;
			$database->setQuery($query);
			if (!$database->query()) {
				echo "Failed to insert userdata";
				return;
			}
		}
	}
}

/*
update current user session data (used on user signoff from chat)
*/
function bc_userSignOff() {
	global $database, $my;

	$myss = bc_getSessionData();

	$query = "UPDATE #__session "
	." SET bc_lastUpdate='' "
	." WHERE session_id='$myss->session_id' "
	;
	$database->setQuery($query);
	$database->query();

	if ($myss->userid || $my->id) {
		$id = 0;
		if ($myss->userid > 0) {
			$id = $myss->userid;
		} else if ($my->id > 0) {
			//in case Joomla session variable is not set properly, we take a look at $my variable
			$id = $my->id;
		} else {
			return;
		}
		$query = "UPDATE #__blastchatc_users "
		." SET bc_rid=0, bc_rsid=0, bc_rname='', bc_idle=''"
		." WHERE bc_userid=$id "
		;
		$database->setQuery($query);
		$database->query();
	}
}

/*
returns URL of your website (self referenced URL)
*/
function bc_getLiveSite($ls) {
	//if $mosConfig_live_site variable is not available, then create it from request data
	//$mosConfig_live_site - holds full URL of your website (no trailing slash at the end), examples: http://www.xxx.com or http://www.xxx.com/something
	//if you are getting this error, replace code "echo ...."  with  $mosConfig_live_site = "http://yourwebsitedomain";
	if (!$ls) {
		$ls = substr_replace(JURI::root(), '', -1, 1);
	}
	if (!$ls) {
		echo "\$mosConfig_live_site variable not defined by system, adjust file api.blastchatc.php, function bc_getLiveSite().";
		exit;
	}
	return $ls;
}

function bc_getVersion() {
	global $_VERSION;
	//prepare variables dependent on system used
	// $_VERSION - variable holding CMS information
	// $_VERSION->PRODUCT - product used
	// $_VERSION->RELEASE - release number of product used
	// $_VERSION->DEV_LEVEL  - development number of product used
	if (!isset($_VERSION)) {
		$bc_version = & new JVersion();
	} else {
		$bc_version = $_VERSION;
	}
	return $bc_version;
}
?>