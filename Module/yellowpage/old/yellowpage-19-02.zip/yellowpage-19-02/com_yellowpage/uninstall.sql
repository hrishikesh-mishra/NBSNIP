DROP TABLE IF EXISTS `#__yellowpage`;

DROP TABLE IF EXISTS `#__yp_club`;

DROP TABLE IF EXISTS `#__yp_doctors`;

DROP TABLE IF EXISTS `#__yp_education`;

DROP TABLE IF EXISTS `#__yp_hotel_lodge`;

DROP TABLE IF EXISTS `#__yp_medical`;

DROP TABLE IF EXISTS `#__yp_vehicle`;
