<div id="layer1" align="center";  style="background-image: url(components/com_classifieds/assets/classifieds.jpg); layer-background-imageurl(components/com_classifieds/assets/classifieds.jpg);  width:400px; height:130px; border: 1px none #000000">
</div>
<div id="layer2" align="center";  style="background-image: url(components/com_classifieds/assets/clasbase.jpg); layer-background-imageurl url(components/com_classifieds/assets/clasbase.jpg);  width:536px; height:35px; border: 1px none #000000">
  <table width="100%" >
  <tr>
	<td width="10"/>
      <td width="70" align="right" height="35"> 
        <div align="center"><a href="<?php echo JRoute::_('index.php?option=com_classifieds&controller=categories')?>"
		style="text-decoration:none"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFF00">| HOME 
          | </font></b></a></div>      </td>
      <td width="89" height="35"> 
        <div align="center"><a href="<?php echo JRoute::_('index.php?option=com_classifieds&controller=categories&cid=1')?>"
		 style="text-decoration:none"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFF00">| REALSTATE 
          |</font></b></a></div>      </td>
      <td width="89" height="35"><div align="center"><a href="<?php echo JRoute::_('index.php?option=com_classifieds&controller=categories&cid=2')?>"
		 style="text-decoration:none"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFF00">| JOBS 
          |</font></b></a></div></td>
      <td width="89" height="35"><div align="center"><a href="<?php echo JRoute::_('index.php?option=com_classifieds&controller=categories&cid=3')?>"
		 style="text-decoration:none"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFF00">| COMPUTER 
          |</font></b></a></div></td>
      <td width="89" height="35"><div align="center"><a href="<?php echo JRoute::_('index.php?option=com_classifieds&controller=categories&cid=4')?>" 
		 style="text-decoration:none"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFF00">| VEHICLE 
          |</font></b></a></div></td>
      <td width="80" height="35"><div align="center"><a href="<?php echo JRoute::_('index.php?option=com_classifieds&controller=categories&cid=5')?>" 
		 style="text-decoration:none"><b><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFF00">| PERSONAL 
          |</font></b></a></div></td>
	<td width="10"/>

  <tr>
  </table>
</div>
