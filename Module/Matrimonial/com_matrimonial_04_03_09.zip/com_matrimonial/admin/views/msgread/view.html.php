<?php

	/* 
		matrimonial message  html view 
	*/

	//direct access not allowed	
	defined( '_JEXEC' ) or die( 'Restricted access view' );

	jimport( 'joomla.application.component.view' );


	class matrimonialViewMsgRead extends JView 
	{
		function display($tpl = null)
		{
					parent::display($tpl);
		}
	}

     
?>