<?php

	/* 
		classifieds Categories  html view 
	*/

	//direct access not allowed	
	defined( '_JEXEC' ) or die( 'Restricted access view' );

	jimport( 'joomla.application.component.view' );


	class matrimonialViewRegistration extends JView 
	{
		function display($tpl = null)
		{
			parent::display($tpl);
		}

     
}
?>