<?php
 
 /* 
	yellow page Vehicle Controller
	
 */


 // direct access not allowed 

 defined ('_JEXEC') or die ('Ristricted Access');

 jimport('joomla.application.component.controller');

 class reportControllermatrimonial extends JController
 {
		


	function __construct()
	{
		$this->_flag=0;

		parent::__construct();

	}


	 function display()
	 {

		 parent::display();
		 
	 }

	 				
}
?>



