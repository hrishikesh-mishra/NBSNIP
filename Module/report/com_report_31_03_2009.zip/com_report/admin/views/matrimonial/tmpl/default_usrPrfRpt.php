<?php 
	defined ('_JEXEC') or die('Restricted Access');	
?>
  
  <table  border="0">
    <tr>
      <td><font color="#333333" size="+2" face="Arial, Helvetica, sans-serif"><strong>Matrimonial User Profile Report </strong></font></td>
    </tr>
	 <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td ><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">User ID </font></strong></td>
      <td><?php echo $this->userPrf->userid ;?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Gender</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->gender; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">weight</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->weight ;?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Body Type</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->bodytype ;?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Complexion</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->complexion ;?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Height</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->height ;?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Mother Tongue </font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->mothertongue; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Community</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->community; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Education</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->education ;?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Profession</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->profession ;?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Monthly Income </font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->monthlyincome ; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Diet</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->diet; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Smoke</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->smoke; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Drink</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->drink ;?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Blood Group </font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->bloodgroup; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Zodic</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->zodic; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Location</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->location; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">City</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->city; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">State</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->state; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Phone</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->phone; ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><strong><font color="#333333" size="2" face="Times New Roman, Times, serif">Mobile</font></strong></td>
      <td align="left" valign="top"><?php echo $this->userPrf->mobile; ?></td>
    </tr>
  </table>

